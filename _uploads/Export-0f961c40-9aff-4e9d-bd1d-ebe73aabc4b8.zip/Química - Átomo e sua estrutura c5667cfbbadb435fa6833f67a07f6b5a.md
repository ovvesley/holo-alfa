# Química - Átomo e sua estrutura

# Massa atômica de elemento químico

Normalmente visualizamos na tabela periódica o numero de massa e consideramos a massa do elemento químico, mas aquele numero é mais complexo do que se é imaginado ao olhar.

A massa atômica de um elemento químico é determinada pela **media ponderada das massas dos isótopos de um elemento químico.**

**Isótopos -  são os elementos químicos que possuem o mesmo numero atômico, assim, possuindo o mesmo número de próton. Diferenciando somente na quantidade de nêutron.**

**Exemplo**:

![Qui%CC%81mica%20-%20A%CC%81tomo%20e%20sua%20estrutura%20c5667cfbbadb435fa6833f67a07f6b5a/Untitled.png](Qui%CC%81mica%20-%20A%CC%81tomo%20e%20sua%20estrutura%20c5667cfbbadb435fa6833f67a07f6b5a/Untitled.png)

***Calculo da média pondera do enxofre:***

$$⁍$$